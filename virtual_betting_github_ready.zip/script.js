let balance = 1000;
let timer = 30;
let interval;
let user = "";

function login() {
  const name = document.getElementById("username").value.trim();
  if (!name) return alert("Enter your name");
  user = name;
  document.getElementById("displayName").textContent = name;
  document.getElementById("login-screen").style.display = "none";
  document.getElementById("main-screen").style.display = "block";
  startTimer();
}

function startTimer() {
  timer = 30;
  document.getElementById("time").textContent = timer;
  interval = setInterval(() => {
    timer--;
    document.getElementById("time").textContent = timer;
    if (timer <= 0) {
      clearInterval(interval);
      endMatch();
    }
  }, 1000);
}

function placeBet(team) {
  if (timer <= 0) return alert("Match ended. Wait for next round.");
  const amount = parseInt(document.getElementById(`bet${team}`).value);
  if (isNaN(amount) || amount <= 0) return alert("Enter valid amount");
  if (amount > balance) return alert("Insufficient balance");

  balance -= amount;
  document.getElementById("balance").textContent = balance;
  localStorage.setItem("bet_" + team, amount);
  alert("Bet placed on Team " + team);
}

function endMatch() {
  const winner = Math.random() > 0.5 ? 'A' : 'B';
  const betKey = "bet_" + winner;
  const winnings = parseInt(localStorage.getItem(betKey)) || 0;
  const earned = winnings * 2;
  balance += earned;
  document.getElementById("balance").textContent = balance;
  document.getElementById("resultMsg").textContent = "Team " + winner + " won! You earned " + earned + " coins.";

  const historyItem = document.createElement("li");
  historyItem.textContent = `Match: Winner Team ${winner} | You earned: ${earned} coins`;
  document.getElementById("history").prepend(historyItem);

  localStorage.removeItem("bet_A");
  localStorage.removeItem("bet_B");

  setTimeout(() => {
    document.getElementById("resultMsg").textContent = "";
    startTimer();
  }, 5000);
}